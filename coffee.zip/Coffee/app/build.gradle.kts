plugins {
    id("com.android.application")
    id("kotlin-android")
}

android {
    namespace = "com.example.coffee" // Mengganti namespace sesuai dengan permintaan
    compileSdk = 34 // Versi terbaru untuk mendukung dependensi

    defaultConfig {
        applicationId = "com.example.coffee" // Sesuaikan applicationId dengan namespace yang digunakan
        minSdk = 26 // Sesuaikan dengan kebutuhan aplikasi
        targetSdk = 34 // Sesuaikan dengan compileSdk
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    kotlinOptions {
        jvmTarget = "17" // Gunakan JVM target 17 untuk Kotlin
    }

    java {
        toolchain {
            languageVersion = JavaLanguageVersion.of(17) // Gunakan Java 17
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Kotlin standard library
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.8.10")

    // AndroidX libraries
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.android.material:material:1.8.0")

    // Room Database
    implementation("androidx.room:room-runtime:2.5.0")

    // Android Core Library
    implementation("androidx.core:core-ktx:1.9.0")

    // Testing dependencies
    androidTestImplementation("androidx.room:room-testing:2.5.0")
    testImplementation("androidx.test.ext:junit-ktx:1.1.5")
    testImplementation("androidx.room:room-testing:2.5.0")

    // Android Instrumentation Testing
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
