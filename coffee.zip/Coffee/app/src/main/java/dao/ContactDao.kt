package com.example.bukutelepon.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.bukutelepon.model.Contact

@Dao
interface ContactDao {

    @Insert
    suspend fun insertContact(contact: Contact): Long

    @Query("SELECT * FROM contacts")
    suspend fun getAllContacts(): List<Contact>
}
