package com.example.bukutelepon.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.bukutelepon.dao.ContactDao
import com.example.bukutelepon.model.Contact

@Database(entities = [Contact::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
}

